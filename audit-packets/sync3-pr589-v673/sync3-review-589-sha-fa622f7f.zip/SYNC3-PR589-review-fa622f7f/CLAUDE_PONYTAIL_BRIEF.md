# Claude Sonnet 5.5: Sync3 PR589 P0, Ponytail debugging only
Repository: https://github.com/jfcarpiopuntocom/friendly-123
PR: https://github.com/jfcarpiopuntocom/friendly-123/pull/589
HEAD: fa622f7f5e039e47d66a10b47dc723d495d6cc38
Base master v670: b918eac359ee42c64190203423c460740377bc58

CURRENT PR MICROFIX: slow RTC receiver no longer blocks initial delivery to healthy peers, deterministic head-of-line test RED->GREEN; full 3-browser CPU1 stress remains RED and P0 unresolved.

MANDATE: ZERO UI/UX/copy changes. ZERO architecture, provider, spec or scope changes. No changes to business/financial/inventory/PIN/role semantics. TDD RED->GREEN from real cause; no removal of caps or arbitrary terminal caps that stop valid causal progress. Never touch production or client data without proved A->B->A x2 physical acceptance and all exact-SHA gates.

CONFIRMED: 8/8 three-browser Chromium direct P2P runs PASS on a 2-core sandbox, but running with taskset -c 0 REPRODUCES Timeout 12000ms at test/peer-sync-browser.test.js line 167. The two peer data channels were OPEN but edits remained unreceived and pending ACKs=2. At one failure: sender queued 12 live frames, bufferedBytes 584354 (queuedBytes 56390, one peer dc buffered 527964). Another failure: queued 7 live frames, bufferedBytes 1100696 (queuedBytes 56382, two DC buffers 528200 and 516114). Changing global SUM to MAX for per-peer DC buffers alone DID NOT solve the RED; do not apply that guess. Linux WebKit RTC preflight failed and test skipped; Safari not proven. Github Actions P2P A/B was intermittently red/green, current run 42141103284 green.

INSPECT: docs/peer-sync.js Socket.bufferedAmount, Hub.nudge, Socket.send serialized sends, Hub.deliver 5s buffer wait, peer receipts/retries. docs/sync-yjs.js enviarConLimite/encolarVivo/drenarVivo/programarBufferPump, durable ack and history replay; test/peer-sync-browser.test.js 3 peers and big photo. Distinguish congestion, stale DC bufferedAmount, live traffic HOL and durable ACK race. No green-by-timeout or reduced assertions.

Also retain Sync3: Yjs missing parents, finite HEAD pacing 4 pages/window and 8s for progress, Firebase same-ms 24 staged pages, durable cursor no rollback, do not checkpoint partial Y.Doc, PIN gate, 600 legacy envelopes. Review 11 changed files in PR_DIFF.patch; preserve independent exact SHA manifest.

Tests: npm ci; npx playwright install chromium webkit
node --require ./test/helpers/sin-red-produccion.cjs --test --test-concurrency=1 --test-timeout=120000 test/peer-sync-browser.test.js
taskset -c 0 node --require ./test/helpers/sin-red-produccion.cjs --test --test-concurrency=1 --test-timeout=120000 --test-name-pattern='direct chromium' test/peer-sync-browser.test.js
node --test test/sync3-head-causal-gap.test.cjs test/yjs-unresolved-checkpoint.test.js test/absorber-legacy-outbox.test.cjs

REQUIRE DELIVERABLE: proven single root cause, minimal patch, reproducible RED then stress GREEN, compatibility with v670/older clients, integrity of photos/ledger/money/PIN, release gate exact SHA, GO/NO-GO. No merger or production deployment without real PC/Safari/PWA license+PIN continuity A->B->A two cycles.


CURRENT CUT fa622f7f: RED->GREEN for cascade buffer admission in docs/relay-selector.js: the previous H.bufferedAmount summed all open durable transport buffered bytes. A full preferred layer starved an empty fallback. Now H reports the least buffered OPEN layer and H.send independently enforces the existing 512KiB cap for EACH layer. Existing exceptional native encrypted checkpoint with empty buffer and daily quota remains intact. New 3 synthetic regression cases in test/relay-selector.test.cjs. 37/37 selector and 139/139 cross-domain targeted tests passed on repeated run. A one-off flake in 600-envelope evidence was observed in the first combined run but isolated and repeat tests passed; do NOT ignore full CI.
IMPORTANT: direct-only P2P remains intermittently RED under single-core load. A laboratory-only experiment changing Socket.bufferedAmount from SUM to MIN yielded 1/4 PASS in CPU1 trials (rejected, not shipped). Do not blame or adjust timeouts to hide the fault. A stale RTC data channel can stay open after pc.connectionState='disconnected' in an affected run; investigate real per-peer channel lifecycle, ACK, SCTP fragmentation and fair scheduling with deterministic RED before changing peer-sync.
Current PR #589 is DRAFT; master v670 untouched. Physical PC/Safari/PWA two A->B->A cycles with same synthetic shop remain required before GO.

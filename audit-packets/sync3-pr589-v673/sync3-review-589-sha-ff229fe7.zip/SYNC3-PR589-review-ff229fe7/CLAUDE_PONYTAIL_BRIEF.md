# Claude Sonnet 5.5: Sync3 PR589 P0, Ponytail debugging only
Repository: https://github.com/jfcarpiopuntocom/friendly-123
PR: https://github.com/jfcarpiopuntocom/friendly-123/pull/589
HEAD: ff229fe7f5f5a85a554f86d19d2786872e28b732
Base master v670: b918eac359ee42c64190203423c460740377bc58

MANDATE: ZERO UI/UX/copy changes. ZERO architecture, provider, spec or scope changes. No changes to business/financial/inventory/PIN/role semantics. TDD RED->GREEN from real cause; no removal of caps or arbitrary terminal caps that stop valid causal progress. Never touch production or client data without proved A->B->A x2 physical acceptance and all exact-SHA gates.

CONFIRMED: 8/8 three-browser Chromium direct P2P runs PASS on a 2-core sandbox, but running with taskset -c 0 REPRODUCES Timeout 12000ms at test/peer-sync-browser.test.js line 167. The two peer data channels were OPEN but edits remained unreceived and pending ACKs=2. At one failure: sender queued 12 live frames, bufferedBytes 584354 (queuedBytes 56390, one peer dc buffered 527964). Another failure: queued 7 live frames, bufferedBytes 1100696 (queuedBytes 56382, two DC buffers 528200 and 516114). Changing global SUM to MAX for per-peer DC buffers alone DID NOT solve the RED; do not apply that guess. Linux WebKit RTC preflight failed and test skipped; Safari not proven. Github Actions P2P A/B was intermittently red/green, current run 42141103284 green.

INSPECT: docs/peer-sync.js Socket.bufferedAmount, Hub.nudge, Socket.send serialized sends, Hub.deliver 5s buffer wait, peer receipts/retries. docs/sync-yjs.js enviarConLimite/encolarVivo/drenarVivo/programarBufferPump, durable ack and history replay; test/peer-sync-browser.test.js 3 peers and big photo. Distinguish congestion, stale DC bufferedAmount, live traffic HOL and durable ACK race. No green-by-timeout or reduced assertions.

Also retain Sync3: Yjs missing parents, finite HEAD pacing 4 pages/window and 8s for progress, Firebase same-ms 24 staged pages, durable cursor no rollback, do not checkpoint partial Y.Doc, PIN gate, 600 legacy envelopes. Review 11 changed files in PR_DIFF.patch; preserve independent exact SHA manifest.

Tests: npm ci; npx playwright install chromium webkit
node --require ./test/helpers/sin-red-produccion.cjs --test --test-concurrency=1 --test-timeout=120000 test/peer-sync-browser.test.js
taskset -c 0 node --require ./test/helpers/sin-red-produccion.cjs --test --test-concurrency=1 --test-timeout=120000 --test-name-pattern='direct chromium' test/peer-sync-browser.test.js
node --test test/sync3-head-causal-gap.test.cjs test/yjs-unresolved-checkpoint.test.js test/absorber-legacy-outbox.test.cjs

REQUIRE DELIVERABLE: proven single root cause, minimal patch, reproducible RED then stress GREEN, compatibility with v670/older clients, integrity of photos/ledger/money/PIN, release gate exact SHA, GO/NO-GO. No merger or production deployment without real PC/Safari/PWA license+PIN continuity A->B->A two cycles.

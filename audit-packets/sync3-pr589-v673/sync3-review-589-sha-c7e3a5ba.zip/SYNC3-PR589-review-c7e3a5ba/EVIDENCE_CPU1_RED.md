Synthetic isolated benchmark, commit c7e3a5ba:
- Chromium normal CPU: 8/8 runs passed.
- One core: intermittent RED with sender 2 unacknowledged durable envelopes and 7-12 live queue frames; 512KiB buffer pressure, RTC connections open, 12-second wait exceeded.
- Native WebKit RTC preflight did not open channel on Linux: SKIP, not Safari certificate.
- Changed MAX instead of SUM buffer experiment failed; NOT in candidate.
- GitHub run for P2P A/B: 42141103284, latest green after earlier red/green 42136366170.

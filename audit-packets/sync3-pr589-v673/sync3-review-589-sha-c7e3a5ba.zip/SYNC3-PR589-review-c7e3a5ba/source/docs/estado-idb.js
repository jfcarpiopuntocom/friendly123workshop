// estado-idb.js — friendly-123 · Espejo del estado del negocio en IndexedDB
// ============================================================================
// BUG QUE ARREGLA (JFC 2026-08-17, en su propia PC, encontrado en amigable-123
// y portado aqui porque la causa es identica: mismo origen, mismo techo):
//   "me dijo 'La memoria de este navegador está llena: los cambios nuevos NO se
//    están guardando' y eso jamas debe decir en mi PC donde soooobra espacio"
//
// Tenia razon y el disco no tenia nada que ver. localStorage NO crece con el
// disco: los navegadores le dan un tope fijo de ~5 MB POR ORIGEN, y las tres
// apps (amigable / friendly-123 / consultorio-123) comparten el mismo origen de
// GitHub Pages. Con fotos de producto y un log de actividad largo, ese techo se
// toca en una PC con 900 GB libres exactamente igual que en un telefono viejo.
//
// IndexedDB, en cambio, SI escala con el disco (tipicamente cientos de MB o mas,
// negociado contra el espacio real disponible). Este modulo guarda ahi una copia
// completa del estado cada vez que se guarda, y mock-backend.js la usa como red:
//
//   1. localStorage funciona  -> se guarda en los dos. Nada cambia para nadie.
//   2. localStorage se lleno  -> IndexedDB recibe el estado COMPLETO igual, y el
//                                cartel rojo de "no se esta guardando" NO sale,
//                                porque seria mentira: si se guardo.
//   3. IndexedDB tampoco pudo -> ahi si, cartel rojo. Eso es un problema de
//                                verdad y el dueno tiene que respaldar ya.
//
// Al arrancar, mock-backend compara la revision (_rev) de los dos y se queda con
// la MAS NUEVA. Si localStorage se quedo atras por falta de espacio, el negocio
// sigue completo igual.
//
// REGLA DE LA CASA: si IndexedDB no existe o falla, todo esto es un no-op y la
// app se comporta exactamente como antes. Cero dependencia obligatoria.
// ============================================================================
(function () {
  "use strict";

  var DB_NAME = "f123_estado";      // aislamiento.js le pone el namespace solo
  var STORE = "estado";
  var CLAVE = "actual";
  var SOPORTADO = ("indexedDB" in window);

  var dbPromise = null;
  function abrirDB() {
    if (dbPromise) return dbPromise;
    var req;
    try { req = indexedDB.open(DB_NAME, 1); } catch (err) { return Promise.reject(err); }
    var promise, settled = false;
    promise = new Promise(function (resolve, reject) {
      function fail(err) {
        if (settled) return;
        settled = true;
        if (dbPromise === promise) dbPromise = null;
        reject(err);
      }
      req.onupgradeneeded = function () {
        if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
      };
      req.onsuccess = function () {
        var db = req.result;
        if (settled) { db.close(); return; }
        settled = true;
        db.onversionchange = function () { db.close(); if (dbPromise === promise) dbPromise = null; };
        resolve(db);
      };
      req.onerror = function () { fail(req.error); };
      req.onblocked = function () { fail(new Error("IndexedDB bloqueado")); };
    });
    dbPromise = promise;
    return promise;
  }

  /* ESCRITURAS AGRUPADAS (caza de bugs 2026-08-18). El espejo se dispara en
     CADA guardado, o sea en cada venta. En una feria con ventas seguidas eran
     decenas de escrituras del estado entero por minuto, cada una serializando
     todo el negocio.

     Se agrupan: la primera escribe ya —para no perder nada si el navegador se
     cierra en el acto— y las siguientes se juntan en una sola al final de la
     rafaga. Nunca se pierde la ULTIMA, que es la que importa.

     `guardar()` sigue devolviendo la promesa del resultado REAL de escritura,
     porque mock-backend decide con eso si sale el cartel rojo: prometer un
     true optimista seria justo la mentira que este modulo vino a quitar. */
  var _pend = null, _reloj = null, _confirmaciones = [], _cola = Promise.resolve();
  var AGRUPAR_MS = 400;

  function volcarPendiente() {
    if (!_pend) return;
    var estado = _pend, confirmar = _confirmaciones;
    _pend = null; _confirmaciones = [];
    guardar(estado).then(function (ok) { confirmar.forEach(function (resolve) { resolve(ok); }); });
  }

  function guardarYa(estado) {
    if (_reloj) { clearTimeout(_reloj); _reloj = null; }
    // Flush older snapshots before queuing this exact durable boundary.
    volcarPendiente();
    return guardar(estado);
  }

  function guardarAgrupado(estado, exigirCompleto) {
    if (!SOPORTADO || !estado) return Promise.resolve(false);
    if (exigirCompleto) return guardarYa(estado);
    /* Primera de la rafaga: va directo, sin esperar. */
    if (!_reloj) {
      /* M3: si guardar rechaza, el next-turn NO deja el reloj colgado. Antes,
         al fallar el guardado en el fin de la rafaga, el reloj se limpiaba
         pero podia haber una escritura pospuesta sin nadie que la disparara. */
      var resultado = guardar(estado);
      _reloj = setTimeout(function () {
        _reloj = null;
        volcarPendiente();
      }, AGRUPAR_MS);
      return resultado;
    }
    /* Dentro de la rafaga: se queda solo la mas nueva. */
    _pend = estado;
    return new Promise(function (resolve) { _confirmaciones.push(resolve); });
  }

  /* Guarda el estado completo. Devuelve true SOLO si de verdad quedo escrito:
     mock-backend decide con esto si el aviso rojo sale o no, asi que aqui no se
     puede ser optimista. */
  function guardar(estado) {
    var resultado = _cola.then(function () { return escribir(estado); });
    _cola = resultado.then(function () {}, function () {});
    return resultado;
  }
  // (JFC 2026-10-28) causa del ultimo fallo de escritura: el clasificador de mock-backend la lee (cuota real -> cartel rojo).
  var _ultimoError = null;
  async function escribir(estado) {
    if (!SOPORTADO || !estado || typeof estado !== "object") return false;
    try {
      var db = await abrirDB();
      const guardado = await new Promise(function (resolve, reject) {
        var tx = db.transaction(STORE, "readwrite");
        // A late mirror must never overwrite a newer cross-tab sale.
        const copia = JSON.parse(JSON.stringify(estado));
        let accepted = false;
        const req = tx.objectStore(STORE).get(CLAVE);
        req.onsuccess = function () {
          const old = req.result;
          if (old && Number(old._rev) >= Number(copia._rev)) {
            accepted = old._rev === copia._rev && old._abCommit === copia._abCommit;
            return;
          }
          tx.objectStore(STORE).put(copia, CLAVE);
          accepted = true;
        };
        tx.oncomplete = function () { resolve(accepted); };
        tx.onerror = function () { reject(tx.error); };
        tx.onabort = function () { reject(tx.error || new Error("abortada")); };
      });
      _ultimoError = null;
      return guardado === true;
    } catch (err) {
      _ultimoError = err || null;
      try { console.error("[estado-idb] guardar:", err); } catch (_) {}
      return false;
    }
  }

  // Atomic durable revision fence. Two tabs cannot acknowledge two different
  // sales from the same base revision. IndexedDB serializes overlapping
  // readwrite transactions; no 10-second Web Locks wait or cross-tab lease.
  function guardarConRevision(estado, revisionAplicada) {
    if (!SOPORTADO || !estado || !Number.isSafeInteger(revisionAplicada)) return Promise.resolve(false);
    const op = _cola.then(async function () {
      const copia = JSON.parse(JSON.stringify(estado));
      const db = await abrirDB();
      return new Promise(function (resolve) {
        let accepted = false, errorTx = null; // cada transacción reporta SOLO su propio error
        // Money/stock uses strict durability where the browser supports the hint.
        const tx = db.transaction(STORE, "readwrite", { durability: "strict" });
        const req = tx.objectStore(STORE).get(CLAVE);
        req.onsuccess = function () {
          const actual = req.result;
          const rev = Number((actual && actual._rev) || 0);
          // Revision fence: another tab already advanced. Not a storage error; the caller retries on the new base.
          if (rev > revisionAplicada || rev >= Number(copia._rev)) return;
          try {
            tx.objectStore(STORE).put(copia, CLAVE);
            accepted = true;
          } catch (error) {
            // An exception inside an IDB callback does not reject the outer
            // Promise. Keep the actual quota cause for the in-UI warning.
            errorTx = error || new Error("IDB put failed");
            try { tx.abort(); } catch (_) { _ultimoError = errorTx; resolve(false); }
          }
        };
        tx.oncomplete = function () {
          _ultimoError = accepted ? null : errorTx; // fence rejection => null, never a stale earlier error
          resolve(accepted);
        };
        tx.onabort = function () {
          _ultimoError = errorTx || tx.error || new Error("IDB transaction aborted");
          resolve(false);
        };
        tx.onerror = function () { errorTx = errorTx || tx.error || null; };
      });
    }).catch(function (e) { _ultimoError = e || null; return false; });
    _cola = op.then(function () {}, function () {});
    return op;
  }

  async function leer() {
    if (!SOPORTADO) return null;
    try {
      var db = await abrirDB();
      return await new Promise(function (resolve, reject) {
        var tx = db.transaction(STORE, "readonly");
        var req = tx.objectStore(STORE).get(CLAVE);
        req.onsuccess = function () { resolve(req.result || null); };
        req.onerror = function () { reject(req.error); };
      });
    } catch (err) {
      try { console.error("[estado-idb] leer:", err); } catch (_) {}
      return null;
    }
  }

  /* Borra el espejo. Se usa en un solo caso legitimo: el dueno activa su
     negocio y elige "empezar vacio". Sin esto, el espejo conserva la revision
     con el catalogo de demo y el rescate asincrono del arranque puede
     repintarlo encima del negocio recien vaciado (JFC 2026-08-19: "dije que
     prefiero la tienda vacia PERO SIGUEN CARGADAS LAS CAMISETAS").

     Tambien cancela cualquier guardado agrupado que estuviera en vuelo: si un
     estado viejo se escribiera 400 ms despues del borrado, el espejo volveria
     a tener la demo y el bug reaparecia en el siguiente arranque. */
  async function borrar() {
    if (!SOPORTADO) return false;
    try {
      if (_reloj) { clearTimeout(_reloj); _reloj = null; }
      _pend = null;
      _confirmaciones.forEach(function (resolve) { resolve(false); }); _confirmaciones = [];
    } catch (_) {}
    var resultado = _cola.then(function () { return borrarActual(); });
    _cola = resultado.then(function () {}, function () {});
    return resultado;
  }
  async function borrarActual() {
    try {
      var db = await abrirDB();
      await new Promise(function (resolve, reject) {
        var tx = db.transaction(STORE, "readwrite");
        tx.objectStore(STORE).delete(CLAVE);
        tx.oncomplete = resolve;
        tx.onerror = function () { reject(tx.error); };
        tx.onabort = function () { reject(tx.error || new Error("abortada")); };
      });
      return true;
    } catch (err) {
      try { console.error("[estado-idb] borrar:", err); } catch (_) {}
      return false;
    }
  }

  /* Cuanto espacio hay DE VERDAD. Sirve para no acusar al dispositivo de estar
     lleno cuando el que se lleno fue el cajoncito de localStorage. */
  async function espacio() {
    try {
      if (!navigator.storage || !navigator.storage.estimate) return null;
      var e = await navigator.storage.estimate();
      if (!e || !e.quota) return null;
      return { usado: e.usage || 0, tope: e.quota, libre: e.quota - (e.usage || 0) };
    } catch (_) { return null; }
  }

  window.OCEstadoIDB = { guardar: guardarAgrupado, guardarYa: guardarYa, guardarConRevision: guardarConRevision, leer: leer, borrar: borrar, espacio: espacio, soportado: SOPORTADO, ultimoError: function () { return _ultimoError; } };
})();

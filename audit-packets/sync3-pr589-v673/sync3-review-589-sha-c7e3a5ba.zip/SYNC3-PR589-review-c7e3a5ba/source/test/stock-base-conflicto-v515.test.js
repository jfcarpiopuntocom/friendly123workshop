// Belen 2026-10-14 15:16: "Yo arregle manualmente. Y se mantuvo el arreglo. O sea no afecto a lo
// de mi compu" (Aya Huma #2: 0 en el telefono, 1 en la compu). Causa: si dos aparatos tienen
// distinta base de stock para el mismo producto, aplicarCatalogo solo avisaba
// "oc-stock-base-conflicto" y nadie convergia nunca; una correccion manual no cruzaba.
// Regla v515: gana el cambio de stock MAS RECIENTE (stockTs); empate = regla determinista.
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { browser } = require('./helpers/browser.cjs');

async function aparato(id, base, pn, stock, ts) {
  const w = browser();
  const fx = await w.request('/api/respaldo/exportar');
  const p = fx.productos.find((x) => Number(x.stockActual) >= 1);
  Object.assign(p, { id, stockActual: stock, stockTs: ts, stockBase: base, stockPN: pn });
  delete p.stockDeficit;
  fx.productos = [p]; fx.ventas = []; fx.movimientos = [];
  await w.request('/api/respaldo/importar', 'POST', fx);
  return w;
}
const stockDe = async (w, id) => (await w.request('/api/respaldo/exportar')).productos.find((x) => x.id === id).stockActual;
function remotoCon(w, id, base, pn, stock, ts) {
  const cat = w.catalog(); const rp = cat.productos.find((x) => x.id === id);
  Object.assign(rp, { stockBase: base, stockPN: pn, stockActual: stock, stockTs: ts });
  return cat;
}

test('base distinta: la correccion mas reciente del otro aparato llega a este', async () => {
  const pc = await aparato('p-aya-2', 3, { pc: { add: 0, sub: 2 } }, 1, 1000);   // compu: 1
  pc.OCSync.aplicarCatalogo(remotoCon(pc, 'p-aya-2', 1, { cel: { add: 0, sub: 1 } }, 0, 5000), null); // celu corrigio a 0 despues
  assert.equal(await stockDe(pc, 'p-aya-2'), 0);
});
test('base distinta: un dato mas viejo del otro aparato no pisa la correccion local mas nueva', async () => {
  const cel = await aparato('p-aya-2', 1, { cel: { add: 0, sub: 1 } }, 0, 5000);
  cel.OCSync.aplicarCatalogo(remotoCon(cel, 'p-aya-2', 3, { pc: { add: 0, sub: 2 } }, 1, 1000), null);
  assert.equal(await stockDe(cel, 'p-aya-2'), 0);
});

test('legacy baseline fork: a future local clock cannot reject the valid remote inventory forever',async()=>{
  const now=Date.now();
  const valid=await aparato('future-fork',4,{valid:{add:5,sub:0}},9,now);
  const future=await aparato('future-fork',8,{future:{add:0,sub:2}},6,now+3600000);
  for(const w of [valid,future])w.OCLatencia={ahoraRelay:()=>now};
  for(let round=0;round<3;round++){
    const a=valid.catalog(),b=future.catalog();
    valid.OCSync.aplicarCatalogo(b,null);future.OCSync.aplicarCatalogo(a,null);
  }
  for(const w of [valid,future]){
    const p=(await w.request('/api/respaldo/exportar')).productos.find(p=>p.id==='future-fork');
    assert.equal(p.stockActual,9,'both directions choose the existing valid legacy winner');
    assert.equal(p.stockBase,4);assert.equal(p.stockTs,now);
    assert.equal(p.stockEvidencias['8'].pn.future.sub,2,'the losing baseline evidence remains recoverable');
    assert.equal(p.stockEvidencias['4'].pn.valid.add,5);
  }
});
test('base distinta con la misma hora: los dos aparatos eligen el mismo numero', async () => {
  const a = await aparato('p-x', 3, { a: { add: 0, sub: 2 } }, 1, 7000);
  a.OCSync.aplicarCatalogo(remotoCon(a, 'p-x', 1, { b: { add: 0, sub: 1 } }, 0, 7000), null);
  const b = await aparato('p-x', 1, { b: { add: 0, sub: 1 } }, 0, 7000);
  b.OCSync.aplicarCatalogo(remotoCon(b, 'p-x', 3, { a: { add: 0, sub: 2 } }, 1, 7000), null);
  assert.equal(await stockDe(a, 'p-x'), await stockDe(b, 'p-x'));
});
test('aparato viejo sin base y numero distinto: adopta el dato con base si es mas reciente', async () => {
  const pc = await aparato('p-leg', null, null, 4, 1000);
  pc.OCSync.aplicarCatalogo(remotoCon(pc, 'p-leg', 2, { cel: { add: 0, sub: 1 } }, 1, 9000), null);
  assert.equal(await stockDe(pc, 'p-leg'), 1);
});
test('despues de converger, una venta en cada aparato se suman (no se pisan)', async () => {
  const pc = await aparato('p-sum', 3, { pc: { add: 0, sub: 2 } }, 1, 1000);
  pc.OCSync.aplicarCatalogo(remotoCon(pc, 'p-sum', 5, { cel: { add: 0, sub: 1 } }, 4, 5000), null);
  assert.equal(await stockDe(pc, 'p-sum'), 4);
  // misma base ya: el celu vende 1 mas y la compu (con su propio contador) vende 1
  pc.OCSync.aplicarCatalogo(remotoCon(pc, 'p-sum', 5, { cel: { add: 0, sub: 2 } }, 3, 6000), null);
  assert.equal(await stockDe(pc, 'p-sum'), 3);
});

// Recorrido completo por el sync REAL (Yjs entre dos aparatos), como el de Belen.
const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm');
const { webcrypto } = require('node:crypto');
const { setTimeout: delay } = require('node:timers/promises');
async function peer() {
  const w = browser(); delete w.JSON;
  Object.assign(w, { crypto: webcrypto, TextEncoder, TextDecoder,
    WebSocket: class { constructor() { throw new Error('No real relay allowed in tests'); } },
    BroadcastChannel: class { constructor() { throw new Error('No cross-test channels'); } } });
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../docs/vendor/yjs-bundle.min.js'), 'utf8'), w);
  w.IndexeddbPersistence = class { once() {} };
  w.localStorage.setItem('f123_owned', JSON.stringify({ licenseCode: 'SYNTHETIC-ISOLATED-FIXTURE' }));
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../docs/sync-yjs.js'), 'utf8'), w);
  for (let i = 0; i < 100 && w.OCYjs.estado !== 'activo'; i++) await delay(10);
  return w;
}
const pasar = (de, a) => { a.Y.applyUpdate(a.OCYjs.doc, de.Y.encodeStateAsUpdate(de.OCYjs.doc), 'red'); a.OCYjs._store.aplicar(); };
async function sincronizar(a, b) { for (let i = 0; i < 3; i++) { a.OCYjs._store.sembrar(); b.OCYjs._store.sembrar(); pasar(a, b); pasar(b, a); } }
async function conBase(w, id, base, pn, stock, ts) {
  const fx = await w.request('/api/respaldo/exportar');
  const p = fx.productos.find((x) => x.stockActual >= 1);
  Object.assign(p, { id, nombre: 'Aya Huma #2', stockActual: stock, stockBase: base, stockPN: pn, stockTs: ts }); delete p.stockDeficit;
  fx.productos = [p]; fx.ventas = []; fx.movimientos = [];
  await w.request('/api/respaldo/importar', 'POST', fx);
}
test('Belen por el sync real: bases distintas convergen, y su correccion manual llega a la compu', async () => {
  const cel = await peer(), pc = await peer();
  await conBase(cel, 'p-aya', 1, { cel: { add: 0, sub: 1 } }, 0, 5000);   // telefono: 0
  await conBase(pc, 'p-aya', 3, { pc: { add: 0, sub: 2 } }, 1, 1000);     // compu: 1
  await sincronizar(cel, pc);
  assert.equal(await stockDe(cel, 'p-aya'), await stockDe(pc, 'p-aya'), 'tras sincronizar los dos dicen lo mismo');
  // Belen corrige a mano en el telefono: +2 (queda 2). La compu tiene que verlo.
  await cel.request('/api/productos/p-aya/ajustar', 'POST', { delta: 2, motivo: 'conteo fisico' });
  await sincronizar(cel, pc);
  assert.equal(await stockDe(cel, 'p-aya'), 2);
  assert.equal(await stockDe(pc, 'p-aya'), 2, 'la correccion manual del telefono llega a la compu');
  // Y una venta en la compu despues se ve en el telefono (ya comparten base).
  await pc.request('/api/productos/p-aya/venta', 'POST', { cantidad: 1 });
  await sincronizar(cel, pc);
  assert.equal(await stockDe(cel, 'p-aya'), 1); assert.equal(await stockDe(pc, 'p-aya'), 1);
});

test('v602 real Yjs phones-to-PC: saved sale keeps stock and money aligned', async () => {
  const cel = await peer(), pc = await peer();
  const ts = Date.now() - 10000;
  await conBase(cel,'p-fixture-alpha',14,{},14,ts);
  await conBase(pc, 'p-fixture-alpha',14,{},14,ts);
  await sincronizar(cel,pc);
  const result = await cel.request('/api/productos/p-fixture-alpha/venta','POST',{cantidad:1});
  assert.ok(result.ventaId,'a durable sale must return its immutable ID');
  await sincronizar(cel,pc);
  assert.equal(await stockDe(cel,'p-fixture-alpha'),13,'phone decremented one real unit');
  assert.equal(await stockDe(pc,'p-fixture-alpha'),13,'PC received one real unit sale');
  const pcBackup = await pc.request('/api/respaldo/exportar');
  assert.equal(pcBackup.ventas.filter(v=>String(v.id)===String(result.ventaId)).length,1,'sale arrived once, not duplicated');
  await sincronizar(cel,pc);
  assert.equal((await pc.request('/api/respaldo/exportar')).ventas.filter(v=>String(v.id)===String(result.ventaId)).length,1,'replay cannot duplicate money');
});

test('v602 phone rejoin with an older 14-versus-13 stock mismatch and a fresh sale',async()=>{
  const cel=await peer(),pc=await peer();
  await conBase(cel,'p-fixture-beta',13,{},13,Date.now()-10000);
  await conBase(pc, 'p-fixture-beta',14,{},14,Date.now()-20000);
  const sold=await cel.request('/api/productos/p-fixture-beta/venta','POST',{cantidad:1});
  assert.ok(sold.ventaId,'phone sale is durably recorded');
  assert.equal(await stockDe(pc,'p-fixture-beta'),14,'PC remains offline with its old inventory');
  await sincronizar(cel,pc);
  assert.equal(await stockDe(pc,'p-fixture-beta'),12,'newer proven phone stock must arrive after rejoin');
  assert.equal(await stockDe(cel,'p-fixture-beta'),12);
  const snapshot=await pc.request('/api/respaldo/exportar');
  assert.equal(snapshot.ventas.filter(v=>v.id===sold.ventaId).length,1,'rejoin preserves the exact sale ID once');
});

test('P0 v603: diverging physical bases cannot discard a different device unique adjustment', async () => {
  // Both replicas know the same product ID but started from distinct historical
  // baselines. Each holds its OWN independent stock operation. LWW must not
  // silently replace one entire operation set with the other.
  const pc = await aparato('fixture-fork', 15, { pc_unique: { add: 3, sub: 0 } }, 18, 1000);
  const phone = await aparato('fixture-fork', 13, { phone_unique: { add: 3, sub: 0 } }, 16, 2000);
  const before = (await pc.request('/api/respaldo/exportar')).productos[0];
  assert.equal(before.stockPN.pc_unique.add, 3);
  pc.OCSync.aplicarCatalogo(phone.catalog(), null);
  const after = (await pc.request('/api/respaldo/exportar')).productos.find(p => p.id === 'fixture-fork');
  // No single correct total can be inferred without reconciling the original
  // baselines. But neither distinct fact may silently disappear.
  assert.equal(after.stockActual, 16, 'preserve winner display until baselines can be proven common');
  assert.ok(after.stockEvidencias && after.stockEvidencias['15'] &&
    after.stockEvidencias['15'].pn.pc_unique.add === 3,
    'FAIL DATA INTEGRITY: local unique operation lost from persistent fork evidence');
  assert.ok(after.stockEvidencias && after.stockEvidencias['13'] &&
    after.stockEvidencias['13'].pn.phone_unique.add === 3,
    'FAIL DATA INTEGRITY: remote unique operation lost from persistent fork evidence');
  const emitted = pc.catalog().productos.find(p => p.id === 'fixture-fork');
  assert.deepEqual(emitted.stockEvidencias, after.stockEvidencias,
    'fork evidence survives the catalog serialization (and can reach Yjs)');
  pc.OCSync.aplicarCatalogo(phone.catalog(), null);
  const twice = (await pc.request('/api/respaldo/exportar')).productos.find(p => p.id === 'fixture-fork');
  assert.deepEqual(twice.stockEvidencias, after.stockEvidencias, 'replay is idempotent; no evidence explosion');
});

test('P0 v603: two Yjs peers preserve both forked baselines after bidirectional replay', async () => {
  const cel = await peer(), pc = await peer();
  await conBase(cel, 'fork-yjs', 13, {phone_op:{add:3,sub:0}}, 16, 2000);
  await conBase(pc, 'fork-yjs', 15, {pc_op:{add:3,sub:0}}, 18, 1000);
  await sincronizar(cel,pc);
  for (const w of [cel,pc]) {
    const snapshot=(await w.request('/api/respaldo/exportar')).productos.find(p=>p.id==='fork-yjs');
    assert.ok(snapshot.stockEvidencias?.['13']?.pn.phone_op?.add===3, 'phone operation retained');
    assert.ok(snapshot.stockEvidencias?.['15']?.pn.pc_op?.add===3, 'PC operation retained');
  }
  await sincronizar(cel,pc);
  const ca=(await cel.request('/api/respaldo/exportar')).productos.find(p=>p.id==='fork-yjs');
  const pa=(await pc.request('/api/respaldo/exportar')).productos.find(p=>p.id==='fork-yjs');
  assert.deepEqual(ca.stockEvidencias,pa.stockEvidencias,'evidence converges independent of replay order');
});

test('P0: stock fork evidence survives local backup export and clean rehydration',async()=>{
  const source=await aparato('fork-backup',15,{pc_local:{add:3,sub:0}},18,1000);
  source.OCSync.aplicarCatalogo(remotoCon(source,'fork-backup',13,
    {phone_remote:{add:3,sub:0}},16,2000),null);
  const exported=await source.request('/api/respaldo/exportar');
  assert.equal(exported.productos.find(p=>p.id==='fork-backup').stockEvidencias['15'].pn.pc_local.add,3);
  const fresh=browser();
  await fresh.request('/api/respaldo/importar','POST',exported);
  const recovered=(await fresh.request('/api/respaldo/exportar')).productos.find(p=>p.id==='fork-backup');
  assert.equal(recovered.stockEvidencias?.['15']?.pn?.pc_local?.add,3,
    'backup import may not discard a contested local operation');
  assert.equal(recovered.stockEvidencias?.['13']?.pn?.phone_remote?.add,3,
    'backup import may not discard remote operation');
  assert.equal(recovered.stockActual,16,
    'uncertain physical stock must not be fabricated during backup recovery');
});

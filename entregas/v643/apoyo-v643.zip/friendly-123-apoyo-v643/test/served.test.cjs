'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {verifyServed}=require('../tools/verify_served.cjs');
const pin=s=>'sha256-'+crypto.createHash('sha256').update(s).digest('hex');
const base='https://synthetic.invalid/app/';
test('served bytes use locally trusted pins and reject an altered HTTP 200',async()=>{
 const pins={'./a.js':pin('expected\n')};
 assert.equal((await verifyServed(base,pins,{fetcher:async()=>new Response('expected\r\n')})).ok,true);
 const bad=await verifyServed(base,pins,{fetcher:async()=>new Response('changed')});assert.equal(bad.ok,false);assert.equal(bad.results[0].code,'HASH_MISMATCH');
});
test('429, corrupt body and refused network remain failures; no retries',async()=>{
 let calls=0;for(const response of[async()=>new Response('limited',{status:429}),async()=>new Response('bad'),async()=>{throw Error('synthetic DNS failure');}]){
  const r=await verifyServed(base,{'./a.js':pin('expected')},{fetcher:async()=>{calls++;return response();}});assert.equal(r.ok,false);
 }assert.equal(calls,3);
});
test('timeout and oversized body have bounded failures',async()=>{
 const timeout=await verifyServed(base,{'./a.js':pin('x')},{timeoutMs:5,fetcher:async(_,o)=>new Promise((_,reject)=>o.signal.addEventListener('abort',()=>reject(Error('aborted'))))});
 assert.equal(timeout.results[0].code,'TIMEOUT');
 const huge=await verifyServed(base,{'./a.js':pin('12345')},{maxBytes:2,fetcher:async()=>new Response('12345')});assert.equal(huge.results[0].code,'RESOURCE_TOO_LARGE');
});
test('rejects credentials, arbitrary remote HTTP, paths outside base, and empty plans',async()=>{
 for(const base of['http://untrusted.invalid/','https://user:secret@synthetic.invalid/'])await assert.rejects(verifyServed(base,{'./a.js':pin('x')}));
 for(const rel of['../secret','./../secret','https://other.invalid/a.js','./%2e%2e/a.js'])await assert.rejects(verifyServed(base,{[rel]:pin('x')}));
 await assert.rejects(verifyServed(base,{}));
});
test('invalid resource limits cannot disable bounds',async()=>{
 for(const options of[{timeoutMs:Infinity},{timeoutMs:NaN},{timeoutMs:0},{maxBytes:Infinity},{maxBytes:0}])await assert.rejects(verifyServed(base,{'./a.js':pin('x')},options));
});

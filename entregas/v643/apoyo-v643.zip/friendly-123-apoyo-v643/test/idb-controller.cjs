'use strict';
const path=require('node:path');
const repo=process.env.F123_REPO||path.resolve(__dirname,'../lab');
require(path.join(repo,'test/helpers/sin-red-produccion.cjs'));
const {chromium}=require(require.resolve('playwright',{paths:[repo]}));
const fs=require('node:fs'),http=require('node:http'),assert=require('node:assert/strict');
const {shellControlador}=require('../tools/controller.cjs');
const {observeMetadata}=require('../tools/evidence.cjs');
const {verifyServed}=require('../tools/verify_served.cjs');
const original=fs.readFileSync(path.join(repo,'docs/estado-idb.js'),'utf8');
const barrier=`  async function leerTrasGuardados() {
    if (_reloj) { clearTimeout(_reloj); _reloj = null; }
    volcarPendiente();
    await _cola;
    return leer();
  }
`;

let idb=original.replace('  async function leer() {',barrier+'  async function leer() {').replace('leer: leer, borrar:','leer: leer, leerTrasGuardados: leerTrasGuardados, borrar:');
assert.notEqual(idb,original);
// Test-only scheduling hook, before actual native IDB transactions.
idb=idb.replace('  async function escribir(estado) {','  async function escribir(estado) { if (window.__holdNext) { window.__holdNext=false; await window.__mirrorGate; } if (window.__rejectNext) { window.__rejectNext=false; return false; }');
const swSource=fs.readFileSync(path.join(repo,'docs/sw.js'),'utf8');
const messageHandler=swSource.slice(swSource.indexOf('self.addEventListener("message", (ev) => {'));
let shell='f123-shell-v640';
const server=http.createServer((req,res)=>{
 res.setHeader('Cache-Control','no-store');
 if(req.url==='/sw.js'){res.setHeader('Content-Type','text/javascript');return res.end(`const CACHE=${JSON.stringify(shell)},CACHE_GENERACION='-synthetic';self.addEventListener('install',()=>self.skipWaiting());self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));\n`+messageHandler);}
 res.setHeader('Content-Type','text/html');res.end('<!doctype html><title>synthetic v643 support</title>');
});
(async()=>{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));let browser;
 try{
  browser=await chromium.launch(process.env.F123_CHROMIUM_EXECUTABLE?{executablePath:process.env.F123_CHROMIUM_EXECUTABLE,args:['--no-sandbox']}:{headless:true});const ctx=await browser.newContext({serviceWorkers:'allow'});const page=await ctx.newPage();await page.goto('http://127.0.0.1:'+server.address().port+'/');
  await assert.rejects(shellControlador(page),/No hay SW controlador/);
  const observer=observeMetadata(page,{origins:{[new URL(page.url()).origin]:'local'},limit:4,sink(){throw Error('synthetic broken observer');}});
  const observedFetch=await page.evaluate(async()=>{const r=await fetch('/?pin=314&license=F123-SYNTHETIC');return r.status;});assert.equal(observedFetch,200);
  await page.addScriptTag({content:idb});
  const mirror=await page.evaluate(async()=>{
   const api=OCEstadoIDB;
   if(!await api.guardarYa({_rev:6,productos:[],ubicaciones:[]}))throw Error('seed not durable');
   __mirrorGate=new Promise(r=>window.__releaseMirror=r);__holdNext=true;
   const accepted=api.guardarYa({_rev:7,productos:[],ubicaciones:[]});
   let done=false;const pending=api.leerTrasGuardados().then(x=>{done=true;return x;});
   const immediate=await api.leer();
   if(done)throw Error('barrier resolved before held write');
   __releaseMirror();const disk=await pending;
   return {before:immediate._rev,after:disk._rev,ack:await accepted};
  });
  assert.deepEqual(mirror,{before:6,after:7,ack:true});
  const grouped=await page.evaluate(async()=>{
   const first=OCEstadoIDB.guardar({_rev:8,productos:[],ubicaciones:[]});
   const second=OCEstadoIDB.guardar({_rev:9,productos:[],ubicaciones:[]});
   const latest=await OCEstadoIDB.leerTrasGuardados();
   return {after:latest._rev,acks:await Promise.all([first,second])};
  });
  assert.deepEqual(grouped,{after:9,acks:[true,true]});
  const refusal=await page.evaluate(async()=>{
   __rejectNext=true;const ack=OCEstadoIDB.guardarYa({_rev:10,productos:[],ubicaciones:[]});
   return {after:(await OCEstadoIDB.leerTrasGuardados())._rev,ack:await ack};
  });
  assert.deepEqual(refusal,{after:9,ack:false});
  await page.evaluate(async()=>{await navigator.serviceWorker.register('/sw.js');await navigator.serviceWorker.ready;});await page.waitForFunction(()=>!!navigator.serviceWorker.controller);
  const before=await shellControlador(page);assert.equal(before,'f123-shell-v640');
  await page.evaluate(()=>document.title='shell v643');
  const claimed=await page.title(),actual=await shellControlador(page);
  assert.equal(actual,'f123-shell-v640');assert.notEqual(actual,'f123-shell-v643');
  console.log(JSON.stringify({nativeIDB:true,mirror,grouped,refusal,controller:{claimed,actual},automaticAdoptionProven:false}));
  const metadata=observer.snapshot();assert.ok(metadata.failures>0);assert.ok(metadata.events.length<=4);assert.doesNotMatch(JSON.stringify(metadata),/314|SYNTHETIC|pin=|license=/);observer.close();
  console.log(JSON.stringify({brokenObserverDidNotBreakProduct:true,metadata}));
  await ctx.close();
 }finally{if(browser)await browser.close();await new Promise(r=>server.close(r));}
})().catch(e=>{console.error(e);process.exitCode=1;});

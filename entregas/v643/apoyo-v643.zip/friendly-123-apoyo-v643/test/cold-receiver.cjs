'use strict';
const path=require('node:path');
const sourceRoot=process.env.F123_REPO||path.resolve(__dirname,'../lab');
require(path.join(sourceRoot,'test/helpers/sin-red-produccion.cjs'));
const {startServer,openDevice,chromium}=require(path.join(sourceRoot,'test/helpers/e2e-app.cjs'));
const fs=require('node:fs');
const assert=require('node:assert/strict');

const source=fs.readFileSync(sourceRoot+'/docs/sync-yjs.js','utf8');
const block=source.slice(source.indexOf('  function _frame('),source.indexOf('  // Carga perezosa'));
const cryptoCode=source.slice(source.indexOf('  async function cifrarBin('),source.indexOf('  // ===',source.indexOf('  async function cifrarBin(')));
const fb=fs.readFileSync(sourceRoot+'/docs/firebase-relay.js','utf8');
const selector=fs.readFileSync(sourceRoot+'/docs/relay-selector.js','utf8');
const stores=new Map();let serverTime=Date.now(),writes=0;
async function fakeHttp({url,options={}}){
 const u=new URL(url),path=u.pathname.replace(/\.json$/,''),parts=path.split('/').filter(Boolean),root=parts.slice(0,2).join('/');
 if(!stores.has(root))stores.set(root,{o:{},k:{}});const db=stores.get(root),kind=parts[2],id=parts[3];
 if(options.method==='PUT'){
  const value=JSON.parse(options.body);if(value.s?.['.sv'])value.s=++serverTime;
  if(db[kind][id])return {status:401,value:{error:'append only'}};
  db[kind][id]=value;writes++;return {status:200,value};
 }
 let value=id?db[kind]?.[id]:db[kind];
 if(!id&&value&&u.searchParams.get('shallow')==='true')value=Object.fromEntries(Object.keys(value).map(k=>[k,true]));
 else if(!id&&kind==='o'){
  let entries=Object.entries(value||{}).sort((a,b)=>a[1].s-b[1].s);
  if(u.searchParams.has('startAt'))entries=entries.filter(x=>x[1].s>=Number(u.searchParams.get('startAt')));
  if(u.searchParams.has('limitToLast'))entries=entries.slice(-Number(u.searchParams.get('limitToLast')));
  if(u.searchParams.has('limitToFirst'))entries=entries.slice(0,Number(u.searchParams.get('limitToFirst')));
  value=Object.fromEntries(entries);
 }
 return {status:200,value:value||null};
}
async function boot(browser,base,room,rows,skipIgnoredBinary){
 // Protocol isolation: same local server, fresh real IDB per context, no app auth/session fixture.
 const ctx=await browser.newContext({serviceWorkers:'block'});
 await ctx.route(u=>!u.href.startsWith(base),r=>r.abort());
 await ctx.route(base+'/synthetic-protocol-empty.html',r=>r.fulfill({status:200,contentType:'text/html',body:'<!doctype html><title>Synthetic protocol</title>'}));
 const page=await ctx.newPage();await page.goto(base+'/synthetic-protocol-empty.html');
 const dev={ctx,page};
 await dev.page.exposeFunction('__fakeFirebase',async args=>{try{return await fakeHttp(args);}catch(e){console.error('FAKE_HTTP_ERROR',args.url,e.message);throw e;}});
 await dev.page.evaluate(async({fb,selector,block,cryptoCode,room,rows,skipIgnoredBinary})=>{
  if(!window.Y)await new Promise((res,rej)=>{const s=document.createElement('script');s.src='./vendor/yjs-bundle.min.js';s.onload=res;s.onerror=rej;document.head.appendChild(s);});
  window.__probe={sent:[],errors:[],checkpoints:[],received:0};
  eval(fb);
  const remote=F123FirebaseRelay.create({db:'http://synthetic-firebase.invalid',EventSource:null,fetch:async(url,options)=>{try{const r=await __fakeFirebase({url,options});return new Response(JSON.stringify(r.value),{status:r.status,headers:{'Content-Type':'application/json',Date:new Date().toUTCString()}});}catch(e){__probe.errors.push({fakeHttpError:e.message});throw e;}}});
  window.F123FirebaseRelay=remote;
  window.F123Relay={ckptFrameBytes:786432,connect(){throw Error('synthetic Supabase unavailable');}};
  localStorage.setItem('f123_relay_cupo_v1',JSON.stringify({dia:new Date().toISOString().slice(0,10),up:0,down:0,pausaHasta:Date.now()+3600000}));
  eval(skipIgnoredBinary?selector.replace('ws.send = function (v) {','ws.send = function (v) { if (capa.relay === fb && typeof v !== "string") return enviar(v);'):selector);
  const connect=F123Relay.connect.bind(F123Relay);
  F123Relay.connect=url=>{if(!url.includes(room))throw Error('Unrelated app channel blocked in isolated probe');const s=connect(url),send=s.send.bind(s);s.send=data=>{
   const kind=typeof data==='string'?JSON.parse(data).k:'binary';
   try{const result=send(data);__probe.sent.push({kind,bytes:typeof data==='string'?new TextEncoder().encode(data).length:data.byteLength});return result;}
   catch(e){__probe.errors.push({kind,name:e.name});throw e;}
  };s.addEventListener('close',e=>__probe.errors.push({close:e.code,reason:e.reason}));s.addEventListener('message',e=>{if(typeof e.data!=='string')__probe.received++;else (__probe.messages||(__probe.messages=[])).push(JSON.parse(e.data));});return s;};
  window.RELAY_URL='wss://friendly123-sync-relay.jfcarpio.workers.dev/sala/';
  window.API={roomId:room,clave:await crypto.subtle.importKey('raw',new Uint8Array(32).fill(7),'AES-GCM',false,['encrypt','decrypt'])};
  window.log=(...args)=>{if(String(args[0]).includes('ckpt'))__probe.checkpoints.push(args.map(String).join(' '));};
  const make=new Function(cryptoCode+block+';return crearCanal;')();
  window.__doc=new Y.Doc();__doc.getMap('productos');__doc.getMap('history');
  window.__journal=new IndexeddbPersistence('urgent-synthetic-'+room,__doc);await __journal.whenSynced;
  if(rows){for(let i=0;i<6;i++)__doc.getMap('productos').set('p'+i,{id:'p'+i,stockBase:6,stockEpochId:'synthetic-epoch',stockPN:{pc:{add:1,sub:0}},stockActual:7});
   for(let i=0;i<rows;i++)__doc.getMap('history').set('h'+i,{id:i,nota:'x'.repeat(1300)+i});}
  window.__channel=make(Y,__doc,'-y','catalogo',true,null,__journal);__channel.conectar();
 },{fb,selector,block,cryptoCode,room,rows,skipIgnoredBinary});
 try { await dev.page.waitForFunction(needComplete=>__channel.ws?.readyState===1&&(!needComplete||!__channel.recuperando),rows>0,{timeout:10000}); }
 catch(e){console.error('BOOT_FACTS',JSON.stringify(await dev.page.evaluate(()=>({probe:__probe,recovery:__channel.recuperando,ws:__channel.ws?.readyState,cupo:F123Relay.estadoCupo()}))));throw e;}
 return dev;
}
(async()=>{
 const {srv,base}=await startServer();let browser;
 try{
  browser=await chromium.launch(process.env.F123_CHROMIUM_EXECUTABLE?{executablePath:process.env.F123_CHROMIUM_EXECUTABLE,args:['--no-sandbox']}:{headless:true});
  const cases=[['candidate',800,false]];
  for(const [label,rows,skip]of cases){
   const room=(label==='small-control'?'a':label==='large-current'?'b':'c').repeat(40),startWrites=writes;
   const a=await boot(browser,base,room,rows,skip);
   const bytes=await a.page.evaluate(()=>{const full=Y.encodeStateAsUpdate(__doc);__channel.enviarUpdate(full);return full.length;});
   await a.page.waitForTimeout(4000);
   const aFacts=await a.page.evaluate(()=>({probe:__probe,cupo:F123Relay.estadoCupo(),socket:__channel.ws?.readyState,products:__doc.getMap('productos').size}));
   await a.ctx.close(); // source really closed before fresh receiver
   const b=await boot(browser,base,room,0,false).catch(e=>({error:e.message}));
   let bFacts;
   if(b.error)bFacts={bootError:b.error};
   else {await b.page.waitForTimeout(1500);bFacts=await b.page.evaluate(async()=>{
    const facts={count:__doc.getMap('productos').size,stocks:Array.from(__doc.getMap('productos').values()).map(p=>p.stockActual),received:__probe.received,recovering:__channel.recuperando};
    if(!__channel.recuperando){const restored=new Y.Doc();restored.getMap('productos');const disk=new IndexeddbPersistence('urgent-synthetic-'+API.roomId,restored);await disk.whenSynced;facts.idbReadback=Array.from(restored.getMap('productos').values()).map(p=>p.stockActual);await disk.destroy();restored.destroy();}
    return facts;
   });await b.ctx.close();}
   if(label==='large-current'){assert.ok(aFacts.probe.errors.some(x=>x.name==='QuotaExceededError'));assert.equal(bFacts.count,0);assert.equal(bFacts.recovering,true);}
   else {assert.deepEqual(bFacts.stocks,[7,7,7,7,7,7]);assert.deepEqual(bFacts.idbReadback,[7,7,7,7,7,7]);assert.equal(bFacts.recovering,false);}
   console.log(JSON.stringify({label,fullStateBytes:bytes,writes:writes-startWrites,quotaUp:aFacts.cupo[1].up,quotaErrors:aFacts.probe.errors.filter(x=>x.name==='QuotaExceededError').length,checkpointDiagnostics:aFacts.probe.checkpoints,b:bFacts}));
  }
 }finally{if(browser)await browser.close();await new Promise(r=>srv.close(r));}
})().catch(e=>{console.error(e);process.exitCode=1;});

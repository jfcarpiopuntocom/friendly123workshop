'use strict';
const path=require('node:path'),fs=require('node:fs'),http=require('node:http'),assert=require('node:assert/strict');
const repo=process.env.F123_REPO||path.resolve(__dirname,'../lab');require(path.join(repo,'test/helpers/sin-red-produccion.cjs'));
const {verifyServed}=require('../tools/verify_served.cjs');
const manifest=JSON.parse(fs.readFileSync(path.join(repo,'docs/version-manifest.json')));
const selected=['./index.html','./auth-ui.js','./estado-idb.js','./relay-selector.js'];
const pins=Object.fromEntries(selected.map(rel=>[rel,manifest.files[rel]]));let corrupt=false;
const server=http.createServer((req,res)=>{
 const rel='.'+new URL(req.url,'http://127.0.0.1').pathname;
 if(!pins[rel]){res.writeHead(404);return res.end();}
 let bytes=fs.readFileSync(path.join(repo,'docs',rel));if(corrupt&&rel==='./auth-ui.js')bytes=Buffer.from('/* synthetic mixed release */');
 res.writeHead(200);res.end(bytes);
});
(async()=>{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 try{
  const base='http://127.0.0.1:'+server.address().port+'/';
  const good=await verifyServed(base,pins);assert.equal(good.ok,true);
  corrupt=true;const bad=await verifyServed(base,pins);assert.equal(bad.ok,false);assert.equal(bad.results.filter(r=>r.state==='FAIL').length,1);assert.equal(bad.results.find(r=>r.resource==='./auth-ui.js').code,'HASH_MISMATCH');
  console.log(JSON.stringify({sourceManifest:manifest.shell,good,bad}));
 }finally{server.closeAllConnections();await new Promise(r=>server.close(r));}
})().catch(e=>{console.error(e);process.exitCode=1;});

'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),{EventEmitter}=require('node:events');
const {spawnSync}=require('node:child_process'),path=require('node:path');
const {runPlan,observeMetadata}=require('../tools/evidence.cjs');
test('failure preserves fixed denominator and marks untouched assertions NOT_RUN',async()=>{
 let third=false;const r=await runPlan([{id:'a',run:async()=>{}},{id:'b',run:async()=>{assert.equal(1,2);}},{id:'c',run:async()=>{third=true;}}]);
 assert.equal(r.expected,3);assert.equal(r.executed,2);assert.equal(r.passed,1);assert.equal(r.failed,1);assert.equal(r.notRun,1);assert.equal(r.ok,false);assert.equal(third,false);
});
test('subprocess exits nonzero for deliberate failure, zero only for all assertions',()=>{
 for(const [args,expected]of[[['--fail'],1],[[],0]]){
  const r=spawnSync(process.execPath,[path.resolve(__dirname,'../tools/evidence.cjs'),...args],{encoding:'utf8'});
  assert.equal(r.status,expected);assert.equal(JSON.parse(r.stdout).ok,expected===0);
 }
});
test('invalid or empty manifests cannot claim PASS',async()=>{
 for(const m of[[],[{id:'a',run:async()=>{}},{id:'a',run:async()=>{}}],[{id:'a'}]])await assert.rejects(runPlan(m));
});
test('observer caps memory, strips secrets, survives sink failure and removes listeners',()=>{
 const page=new EventEmitter(),obs=observeMetadata(page,{origins:{'https://synthetic.invalid':'firebase'},limit:2,sink(){throw Error('sink broken');}});
 const response={url:()=> 'https://synthetic.invalid/private-room?pin=314&license=F123-SECRET',status:()=>429,request:()=>({method:()=> 'PUT',resourceType:()=> 'fetch',postData:()=> 'NEVER_READ'})};
 page.emit('response',response);page.emit('pageerror',Error('PIN=314 SECRET'));page.emit('requestfailed',{});
 const r=obs.snapshot();assert.equal(r.events.length,2);assert.equal(r.dropped,1);assert.equal(r.failures,3);assert.doesNotMatch(JSON.stringify(r),/314|SECRET|private-room|pin|license|NEVER_READ/);
 obs.close();assert.equal(page.listenerCount('response'),0);page.emit('response',response);assert.deepEqual(obs.snapshot(),r);
});
test('callbacks cannot shrink or rename the captured plan',async()=>{
 const steps=[{id:'first',run:async()=>{steps.pop();steps[1].id='mutated';}},{id:'second',run:async()=>{}},{id:'third',run:async()=>{}}];
 const r=await runPlan(steps);assert.equal(r.expected,3);assert.equal(r.executed,3);assert.deepEqual(r.results.map(x=>x.id),['first','second','third']);assert.equal(r.ok,true);
});

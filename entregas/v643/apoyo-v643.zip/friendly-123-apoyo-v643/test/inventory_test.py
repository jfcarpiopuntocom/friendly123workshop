import importlib.util,json,subprocess,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
TOOL=ROOT/'tools/external_inventory.py'
class Audit(unittest.TestCase):
 def test_version_integrity_and_extra_remote_drift_fail_but_comments_do_not(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);(p/'docs').mkdir();(p/'src/dashboard').mkdir(parents=True)
   (p/'src/dashboard/dashboard-main.js').write_text('')
   html='<script src="https://cdn.example/lib@1.2.3/x.js" integrity="sha384-abc" crossorigin="anonymous"></script>'
   file=p/'docs/index.html';file.write_text(html)
   r=subprocess.run(['python',str(TOOL),str(p)],capture_output=True,text=True);self.assertEqual(r.returncode,0)
   baseline=p/'baseline.json';baseline.write_text(r.stdout)
   for body,code in [(html,0),('<!-- note -->\n'+html,0),(html.replace('@1.2.3','@latest'),1),(html.replace('sha384-abc','sha384-changed'),1),(html+'<script src="//other.example/x.js"></script>',1)]:
    file.write_text(body);r=subprocess.run(['python',str(TOOL),str(p),'--baseline',str(baseline)],capture_output=True,text=True);self.assertEqual(r.returncode,code)
if __name__=='__main__':unittest.main()

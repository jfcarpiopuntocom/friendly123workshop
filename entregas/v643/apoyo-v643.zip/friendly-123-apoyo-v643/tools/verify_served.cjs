'use strict';
const crypto=require('node:crypto');
async function verifyServed(base,pins,{fetcher=fetch,timeoutMs=4000,maxBytes=8*1024*1024}={}) {
  if(!Number.isFinite(timeoutMs)||timeoutMs<1||timeoutMs>60000||!Number.isSafeInteger(maxBytes)||maxBytes<1||maxBytes>32*1024*1024||typeof fetcher!=='function')throw Error('Require finite timeout and body limits');
  const root=new URL(base);if(!root.pathname.endsWith('/'))throw Error('Base must end with /');
  if(root.username||root.password||root.search||root.hash||!(root.protocol==='https:'||(root.protocol==='http:'&&['localhost','127.0.0.1','[::1]'].includes(root.hostname))))throw Error('Use a public HTTPS or local fixture base without credentials');
  if(!Object.keys(pins).length)throw Error('Pin at least one trusted resource');
  for(const [rel,pin]of Object.entries(pins))if(!/^\.\/[a-zA-Z0-9_./-]+$/.test(rel)||rel.split('/').includes('..')||!/^sha256-[a-f0-9]{64}$/.test(pin))throw Error('Invalid trusted manifest entry');
  const results=[];
  for(const [rel,pin]of Object.entries(pins)) {
    const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),timeoutMs);let code='NETWORK_ERROR';
    try {
      const response=await fetcher(new URL(rel,root),{signal:abort.signal,redirect:'error',cache:'no-store',credentials:'omit'});
      if(response.status!==200){try { await response.body?.cancel(); } catch (_) {} results.push({resource:rel,state:'FAIL',code:'HTTP_'+response.status});continue;}
      let size=0;const chunks=[];const reader=response.body.getReader();
      for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>maxBytes){code='RESOURCE_TOO_LARGE';await reader.cancel();throw Error(code);}chunks.push(value);}
      let bytes=Buffer.concat(chunks);if(/\.(html|js|json|css)$/i.test(rel))bytes=Buffer.from(bytes.toString('utf8').replace(/\r\n/g,'\n'));
      const digest='sha256-'+crypto.createHash('sha256').update(bytes).digest('hex');
      results.push(digest===pin?{resource:rel,state:'PASS'}:{resource:rel,state:'FAIL',code:'HASH_MISMATCH'});
    }catch(_){results.push({resource:rel,state:'FAIL',code:abort.signal.aborted?'TIMEOUT':code});}
    finally{clearTimeout(timer);}
  }
  return {ok:results.every(x=>x.state==='PASS'),results};
}
module.exports={verifyServed};
if(require.main===module)(async()=>{
 const fs=require('node:fs'),[base,file,...paths]=process.argv.slice(2);const manifest=JSON.parse(fs.readFileSync(file));
 if(!paths.length)throw Error('Select public assets from a locally trusted manifest');
 const pins=Object.fromEntries(paths.map(rel=>{if(!manifest.files[rel])throw Error('Unknown trusted resource');return [rel,manifest.files[rel]];}));
 const result=await verifyServed(base,pins);console.log(JSON.stringify(result));process.exitCode=result.ok?0:1;
})().catch(()=>{process.stderr.write('Verification could not run\n');process.exitCode=1;});

'use strict';
// Development-only. No network transport or storage writes.
async function runPlan(steps) {
  if (!Array.isArray(steps) || !steps.length || steps.some(s=>typeof s.id!=='string'||!s.id||typeof s.run!=='function') || new Set(steps.map(s=>s.id)).size!==steps.length)
    throw Error('Declare all expected steps with unique ids and assertion functions');
  const plan=steps.map(({id,run})=>Object.freeze({id,run}));
  const results=plan.map(s=>({id:s.id,state:'NOT_RUN'}));
  for(let i=0;i<plan.length;i++) {
    try { await plan[i].run(); results[i].state='PASS'; }
    catch (_) { results[i].state='FAIL'; break; } // no customer-bearing exception text
  }
  const count=state=>results.filter(r=>r.state===state).length;
  return {expected:plan.length,executed:count('PASS')+count('FAIL'),passed:count('PASS'),failed:count('FAIL'),notRun:count('NOT_RUN'),ok:results.every(r=>r.state==='PASS'),results};
}
function observeMetadata(page,{origins={},limit=128,sink=()=>{}}={}) {
  if(!Number.isInteger(limit)||limit<1||limit>1024)throw Error('Bound observer capacity');
  const labels=new Set(['local','supabase','firebase','license']);
  if(Object.values(origins).some(x=>!labels.has(x)))throw Error('Only predefined provider labels');
  const events=[];let failures=0,dropped=0,closed=false;
  const emit=row=>{if(closed)return;try{if(events.length===limit){events.shift();dropped++;}events.push(row);sink({...row});}catch(_){failures++;}};
  const response=r=>{try{
    const request=r.request(),method=request.method(),type=request.resourceType();
    emit({kind:'response',provider:origins[new URL(r.url()).origin]||'external',
      method:['GET','POST','PUT','PATCH','DELETE','HEAD','OPTIONS'].includes(method)?method:'OTHER',
      type:['document','script','stylesheet','fetch','xhr','font','image'].includes(type)?type:'other',status:r.status()});
  }catch(_){failures++;}};
  const failed=()=>emit({kind:'requestfailed',code:'NETWORK_FAILURE'});
  const error=()=>emit({kind:'pageerror',code:'JS_ERROR'});
  page.on('response',response);page.on('requestfailed',failed);page.on('pageerror',error);
  return {snapshot:()=>({events:events.map(x=>({...x})),failures,dropped}),close(){closed=true;page.off('response',response);page.off('requestfailed',failed);page.off('pageerror',error);}};
}
module.exports={runPlan,observeMetadata};
if(require.main===module)(async()=>{
  const report=await runPlan([{id:'first',run:async()=>{}},{id:'second',run:async()=>{if(process.argv.includes('--fail'))throw Error('synthetic failure');}},{id:'third',run:async()=>{}}]);
  console.log(JSON.stringify(report));process.exitCode=report.ok?0:1;
})().catch(()=>{process.exitCode=1;});

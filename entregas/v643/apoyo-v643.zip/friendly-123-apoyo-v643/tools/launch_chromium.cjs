'use strict';
if(process.env.F123_CHROMIUM_EXECUTABLE){
 const path=require('node:path'),repo=process.env.F123_REPO||path.resolve(__dirname,'../lab');
 const {chromium}=require(require.resolve('playwright',{paths:[repo]}));const launch=chromium.launch.bind(chromium);
 chromium.launch=options=>launch({...options,executablePath:process.env.F123_CHROMIUM_EXECUTABLE,args:[...(options?.args||[]),'--no-sandbox']});
}

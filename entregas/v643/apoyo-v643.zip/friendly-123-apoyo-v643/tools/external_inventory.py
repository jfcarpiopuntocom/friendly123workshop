#!/usr/bin/env python3
"""Dev-only declaration drift audit; never fetches or executes resources."""
import argparse, difflib, json, re
from html.parser import HTMLParser
from pathlib import Path
class Resources(HTMLParser):
 def __init__(self,file):super().__init__();self.file=file;self.rows=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs);url=a.get('src') if tag=='script' else a.get('href') if tag=='link' and 'stylesheet' in a.get('rel','').lower().split() else None
  if url and re.match(r'^(?:https?:)?//',url):
   self.rows.append(dict(file=self.file,line=self.getpos()[0],kind=tag,url=url,integrity=a.get('integrity',''),crossorigin=a.get('crossorigin','')))
def inventory(root):
 root=Path(root);rows=[]
 for file in sorted((root/'docs').glob('*.html')):
  p=Resources(str(file.relative_to(root)));p.feed(file.read_text());rows+=p.rows
 file=root/'src/dashboard/dashboard-main.js';text=file.read_text()
 for m in re.finditer(r'cargarHerramientaExportacion\(\s*["\'](https?://[^"\']+)["\']',text):
  rows.append(dict(file=str(file.relative_to(root)),line=text.count('\n',0,m.start())+1,kind='dynamic-export',url=m.group(1),integrity='',crossorigin=''))
 return sorted(rows,key=lambda x:(x['file'],x['line'],x['url']))
def main():
 p=argparse.ArgumentParser();p.add_argument('root');p.add_argument('--baseline');a=p.parse_args();rows=inventory(a.root)
 actual=json.dumps(rows,indent=2,ensure_ascii=False)+'\n'
 if a.baseline:
  expected=Path(a.baseline).read_text()
  semantic=lambda data:sorted([{k:v for k,v in row.items() if k!='line'} for row in data],key=lambda row:json.dumps(row,sort_keys=True))
  if semantic(rows)!=semantic(json.loads(expected)):
   print(''.join(difflib.unified_diff(expected.splitlines(True),actual.splitlines(True),fromfile='baseline',tofile='current')),end='');return 1
 print(actual,end='');return 0
if __name__=='__main__':raise SystemExit(main())

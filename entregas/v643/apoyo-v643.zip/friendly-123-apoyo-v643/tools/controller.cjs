'use strict';
async function shellControlador(page) {
  return page.evaluate(() => new Promise((resolve, reject) => {
    const sw = navigator.serviceWorker, controller = sw?.controller;
    if (!controller) return reject(Error('No hay SW controlador'));
    const finish = (error, value) => {
      clearTimeout(timer); sw.removeEventListener('message', receive);
      error ? reject(error) : resolve(value);
    };
    const receive = event => {
      if (event.source !== controller || event.data?.tipo !== 'shell-actual') return;
      if (sw.controller !== controller) return finish(Error('Cambió el controlador; repetir lectura'));
      finish(null, event.data.shell);
    };
    const timer = setTimeout(() => finish(Error('El controlador no respondió')), 2000);
    sw.addEventListener('message', receive);
    try { controller.postMessage({tipo:'que-shell'}); } catch (error) { finish(error); }
  }));
}
module.exports = {shellControlador};

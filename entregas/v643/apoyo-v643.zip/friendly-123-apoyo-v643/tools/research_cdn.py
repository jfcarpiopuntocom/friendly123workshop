#!/usr/bin/env python3
# Research only: four public GETs; no product changes or customer inputs.
import base64,hashlib,io,json,tarfile,urllib.request
PACKAGE='tabulator-tables';VERSION='6.3.1'
def get(url,limit=16*1024*1024):
 with urllib.request.urlopen(url,timeout=25) as r:
  data=r.read(limit+1)
  if len(data)>limit:raise ValueError('public resource too large')
  return data
meta=json.loads(get(f'https://registry.npmjs.org/{PACKAGE}/{VERSION}',1024*1024))
archive=get(meta['dist']['tarball']);integrity=meta['dist']['integrity'];algo,encoded=integrity.split('-',1)
assert algo=='sha512' and base64.b64encode(hashlib.sha512(archive).digest()).decode()==encoded
results=[]
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tf:
 for path in ['dist/js/tabulator.min.js','dist/css/tabulator_simple.min.css']:
  official=tf.extractfile('package/'+path).read()
  url=f'https://cdn.jsdelivr.net/npm/{PACKAGE}@{VERSION}/{path}';mirror=get(url)
  assert official==mirror,'CDN mirror differs from package tarball'
  results.append({'url':url,'bytes':len(mirror),'equalsNpmArchive':True,'integrity':'sha384-'+base64.b64encode(hashlib.sha384(mirror).digest()).decode()})
print(json.dumps({'package':PACKAGE,'version':VERSION,'npmArchiveIntegrityVerified':True,'resources':results},indent=2))

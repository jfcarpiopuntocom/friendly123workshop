'use strict';
const fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
const {runPlan}=require('./tools/evidence.cjs');
const root=__dirname,repo=path.resolve(process.env.F123_REPO||path.join(root,'lab')),out=path.join(root,'evidence');fs.mkdirSync(out,{recursive:true});
const crypto=require('node:crypto');
const git=spawnSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8',timeout:2000});
const files=['docs/estado-idb.js','docs/auth-ui.js','docs/mock-backend.js','docs/sw.js','docs/version-manifest.json'];
fs.writeFileSync(path.join(out,'execution-context.json'),JSON.stringify({
 gitCommit:git.status===0?git.stdout.trim():null,
 shell:JSON.parse(fs.readFileSync(path.join(repo,'docs/version.json'))).shell,
 files:Object.fromEntries(files.map(file=>[file,crypto.createHash('sha256').update(fs.readFileSync(path.join(repo,file))).digest('hex')]))
},null,2)+'\n');
function command(id,exe,args,timeout=45000){return {id,run:async()=>{
 const r=spawnSync(exe,args,{cwd:repo,env:{...process.env,F123_REPO:repo},encoding:'utf8',timeout,maxBuffer:1024*1024});
 fs.writeFileSync(path.join(out,id+'.log'),(r.stdout||'')+(r.stderr||'')+(r.error?'\nPROCESS_ERROR_OR_TIMEOUT\n':''));
 if(r.status!==0||r.error)throw Error(id+' failed');
}};}
// Declare the complete local-support manifest before the first subprocess.
const steps=[
 command('tool-tests',process.execPath,['--test',path.join(root,'test/evidence.test.cjs'),path.join(root,'test/served.test.cjs')]),
 command('inventory-tests','python',[path.join(root,'test/inventory_test.py')]),
 command('inventory-baseline','python',[path.join(root,'tools/external_inventory.py'),repo,'--baseline',path.join(root,'evidence/external-baseline.json')]),
 command('served-local',process.execPath,[path.join(root,'test/served-local.cjs')]),
 command('idb-controller',process.execPath,[path.join(root,'test/idb-controller.cjs')]),
 command('cold-receiver',process.execPath,[path.join(root,'test/cold-receiver.cjs')]),
 command('base-adjacent',process.execPath,['--require',path.join(root,'tools/launch_chromium.cjs'),'--require',path.join(repo,'test/helpers/sin-red-produccion.cjs'),'--test',...['relay-selector.test.cjs','p0-v637-manifest.test.cjs','p0-durable-stock-adjustment.test.cjs','p0-v641-quantity-mobile.test.cjs'].map(p=>path.join(repo,'test',p))])
];
(async()=>{const report=await runPlan(steps);fs.writeFileSync(path.join(out,'support-summary.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));process.exitCode=report.ok?0:1;})().catch(()=>{process.exitCode=1;});
